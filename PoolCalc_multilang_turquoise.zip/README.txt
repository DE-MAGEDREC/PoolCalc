PoolCalc - Version prête à héberger (site statique) avec thème turquoise "piscine"
Contenu:
- index.html : application single-page (HTML + JS)
Instructions:
- Décompressez le fichier ZIP.
- Déposez le contenu sur un hébergement statique (Netlify, Vercel, GitHub Pages, ou tout serveur web).
- Ouvrez index.html dans un navigateur pour tester localement.
Notes:
- Thème turquoise pour l'ambiance "piscine".
- C'est une version statique prête à héberger (pas besoin de Node.js).
- Les calculs sont indicatifs; vérifiez les coefficients pour usage professionnel.
